import click
import os
from pathlib import Path
from .docker_manager import DockerManager
from .environment import EnvironmentDetector


@click.group()
def cli():
    """Claude Container - Run Claude Code in isolated Docker environments"""
    pass


@cli.command()
@click.option('--dockerfile', help='Path to custom Dockerfile')
@click.option('--force-rebuild', is_flag=True, help='Force rebuild of container image')
def build(dockerfile, force_rebuild):
    """Build Docker container for the current project"""
    project_root = Path.cwd()
    data_dir = project_root / '.claude-container'
    data_dir.mkdir(exist_ok=True)
    
    docker_manager = DockerManager(project_root, data_dir)
    
    click.echo(f"Building container for project: {project_root}")
    
    if dockerfile and Path(dockerfile).exists():
        click.echo(f"Using provided Dockerfile: {dockerfile}")
        image_name = docker_manager.build_from_dockerfile(dockerfile, force_rebuild)
    else:
        click.echo("No Dockerfile provided. Analyzing project environment...")
        env_detector = EnvironmentDetector(project_root)
        environment = env_detector.detect()
        click.echo(f"Detected environment: {environment}")
        image_name = docker_manager.build_from_environment(environment, force_rebuild)
    
    click.echo(f"Container image built: {image_name}")


@cli.command()
@click.option('--claude-code-path', envvar='CLAUDE_CODE_PATH', help='Path to Claude Code executable')
@click.argument('command', nargs=-1)
def run(claude_code_path, command):
    """Run command in the container with Claude Code mounted"""
    project_root = Path.cwd()
    data_dir = project_root / '.claude-container'
    
    if not data_dir.exists():
        click.echo("No container found. Please run 'build' first.")
        return
    
    docker_manager = DockerManager(project_root, data_dir)
    
    if not claude_code_path:
        claude_code_path = docker_manager.find_claude_code()
        if not claude_code_path:
            click.echo("Claude Code executable not found. Please specify --claude-code-path")
            return
    
    click.echo(f"Running in container with Claude Code: {claude_code_path}")
    docker_manager.run_container(claude_code_path, command)


@cli.command()
def clean():
    """Clean up container data and images"""
    project_root = Path.cwd()
    data_dir = project_root / '.claude-container'
    
    if data_dir.exists():
        docker_manager = DockerManager(project_root, data_dir)
        docker_manager.cleanup()
        click.echo("Cleaned up container resources")
    else:
        click.echo("No container data found")


if __name__ == '__main__':
    cli()