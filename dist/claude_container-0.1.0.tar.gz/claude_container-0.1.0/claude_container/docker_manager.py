import docker
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Dict, Any


class DockerManager:
    def __init__(self, project_root: Path, data_dir: Path):
        self.project_root = project_root
        self.data_dir = data_dir
        self.client = docker.from_env()
        self.config_file = data_dir / 'container_config.json'
        self.image_name = f"claude-container-{project_root.name}".lower()
    
    def build_from_dockerfile(self, dockerfile_path: str, force_rebuild: bool = False) -> str:
        """Build container from existing Dockerfile"""
        if not force_rebuild and self._image_exists():
            return self.image_name
        
        dockerfile_content = Path(dockerfile_path).read_text()
        
        # Ensure Node.js is installed
        if 'node' not in dockerfile_content.lower():
            dockerfile_content = self._inject_node_installation(dockerfile_content)
            
        # Write modified Dockerfile
        temp_dockerfile = self.data_dir / 'Dockerfile'
        temp_dockerfile.write_text(dockerfile_content)
        
        # Build image
        self.client.images.build(
            path=str(self.project_root),
            dockerfile=str(temp_dockerfile),
            tag=self.image_name,
            rm=True
        )
        
        self._save_config({'type': 'dockerfile', 'source': dockerfile_path})
        return self.image_name
    
    def build_from_environment(self, environment: Dict[str, Any], force_rebuild: bool = False) -> str:
        """Build container based on detected environment"""
        if not force_rebuild and self._image_exists():
            return self.image_name
        
        dockerfile_content = self._generate_dockerfile(environment)
        
        # Write Dockerfile
        dockerfile_path = self.data_dir / 'Dockerfile'
        dockerfile_path.write_text(dockerfile_content)
        
        # Build image
        self.client.images.build(
            path=str(self.project_root),
            dockerfile=str(dockerfile_path),
            tag=self.image_name,
            rm=True
        )
        
        self._save_config({'type': 'generated', 'environment': environment})
        return self.image_name
    
    def run_container(self, claude_code_path: str, command: List[str]):
        """Run container with Claude Code mounted"""
        volumes = {
            str(self.project_root): {'bind': '/workspace', 'mode': 'rw'},
            claude_code_path: {'bind': '/usr/local/bin/claude', 'mode': 'ro'}
        }
        
        # Prepare command
        if command:
            cmd = ' '.join(command)
        else:
            cmd = '/bin/bash'
        
        container = self.client.containers.run(
            self.image_name,
            cmd,
            volumes=volumes,
            working_dir='/workspace',
            tty=True,
            stdin_open=True,
            detach=True,
            environment={
                'CLAUDE_CODE_AVAILABLE': '1'
            }
        )
        
        # Attach to container
        try:
            subprocess.run(['docker', 'attach', container.id])
        finally:
            container.stop()
            container.remove()
    
    def find_claude_code(self) -> Optional[str]:
        """Try to find Claude Code executable"""
        # Common locations
        paths = [
            '/usr/local/bin/claude',
            '/opt/claude-code/claude',
            str(Path.home() / '.local' / 'bin' / 'claude'),
            shutil.which('claude')
        ]
        
        for path in paths:
            if path and Path(path).exists():
                return path
        
        return None
    
    def cleanup(self):
        """Clean up container resources"""
        try:
            # Remove image
            self.client.images.remove(self.image_name, force=True)
        except:
            pass
        
        # Remove data directory
        if self.data_dir.exists():
            shutil.rmtree(self.data_dir)
    
    def _image_exists(self) -> bool:
        """Check if image already exists"""
        try:
            self.client.images.get(self.image_name)
            return True
        except docker.errors.ImageNotFound:
            return False
    
    def _inject_node_installation(self, dockerfile_content: str) -> str:
        """Inject Node.js installation into Dockerfile"""
        lines = dockerfile_content.split('\n')
        
        # Find a good place to insert Node.js installation
        insert_index = 0
        for i, line in enumerate(lines):
            if line.strip().startswith('RUN'):
                insert_index = i + 1
                break
        
        node_install = """
# Install Node.js
RUN curl -fsSL https://deb.nodesource.com/setup_lts.x | bash - && \\
    apt-get install -y nodejs
"""
        
        lines.insert(insert_index, node_install)
        return '\n'.join(lines)
    
    def _generate_dockerfile(self, environment: Dict[str, Any]) -> str:
        """Generate Dockerfile based on environment"""
        base_image = environment.get('base_image', 'ubuntu:22.04')
        language = environment.get('language', 'unknown')
        
        dockerfile = f"""FROM {base_image}

# Install basic tools
RUN apt-get update && apt-get install -y \\
    curl \\
    wget \\
    git \\
    vim \\
    build-essential \\
    && rm -rf /var/lib/apt/lists/*

# Install Node.js
RUN curl -fsSL https://deb.nodesource.com/setup_lts.x | bash - && \\
    apt-get install -y nodejs

"""
        
        # Add language-specific installations
        if language == 'python':
            dockerfile += """
# Install Python
RUN apt-get update && apt-get install -y \\
    python3 \\
    python3-pip \\
    python3-venv \\
    && rm -rf /var/lib/apt/lists/*

# Install Poetry
RUN curl -sSL https://install.python-poetry.org | python3 -
ENV PATH="/root/.local/bin:$PATH"
"""
        elif language == 'javascript' or language == 'typescript':
            dockerfile += """
# Already have Node.js installed
RUN npm install -g yarn pnpm
"""
        elif language == 'rust':
            dockerfile += """
# Install Rust
RUN curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
ENV PATH="/root/.cargo/bin:$PATH"
"""
        
        dockerfile += """
# Set working directory
WORKDIR /workspace

# Copy project files
COPY . .

# Install dependencies if applicable
"""
        
        if environment.get('package_manager') == 'poetry' and Path(self.project_root / 'pyproject.toml').exists():
            dockerfile += "RUN poetry install || true\n"
        elif environment.get('package_manager') == 'pip' and Path(self.project_root / 'requirements.txt').exists():
            dockerfile += "RUN pip3 install -r requirements.txt || true\n"
        elif environment.get('package_manager') == 'npm' and Path(self.project_root / 'package.json').exists():
            dockerfile += "RUN npm install || true\n"
        elif environment.get('package_manager') == 'yarn' and Path(self.project_root / 'package.json').exists():
            dockerfile += "RUN yarn install || true\n"
        
        dockerfile += "\nCMD [\"/bin/bash\"]"
        
        return dockerfile
    
    def _save_config(self, config: Dict[str, Any]):
        """Save container configuration"""
        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=2)
    
    def _load_config(self) -> Optional[Dict[str, Any]]:
        """Load container configuration"""
        if self.config_file.exists():
            with open(self.config_file) as f:
                return json.load(f)
        return None