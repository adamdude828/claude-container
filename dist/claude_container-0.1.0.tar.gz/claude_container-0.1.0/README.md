# Claude Container

A CLI utility that wraps Claude Code with Docker to provide isolated environments for running Claude Code locally.

## Installation

```bash
poetry install
```

## Usage

```bash
# Build container for current project
claude-container build

# Run command in container
claude-container run -- npm test

# Clean up container resources
claude-container clean
```